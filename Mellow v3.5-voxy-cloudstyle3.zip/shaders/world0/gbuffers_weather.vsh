#version 400 compatibility
#define DIMENSION_OVERWORLD

#include "/program/gbuffers_weather.vsh"
